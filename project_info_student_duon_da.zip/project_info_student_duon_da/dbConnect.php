    <!-- veriable ($connect) use for store data from database -->
<?php 
    $connect = mysqli_connect("localhost","root","","final_exam");
    // if ($connect = mysqli_connect_errno () == 0){
    //     echo "success";
    // }else{
    //     die("faidel");
    // }

?>
