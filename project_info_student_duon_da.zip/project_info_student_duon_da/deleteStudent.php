<!-- This is syntax for delete data in the database -->
<?php 
    include_once "dbConnect.php";
    $id    = $_GET['id'];
    $query = mysqli_query($connect,"DELETE FROM tbl_student WHERE stu_id = $id");
    if ($query == TRUE){
        header("location: index.php");
    }else{
        echo "cannot delete";
    }
?>